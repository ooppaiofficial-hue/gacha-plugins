<?php
/**
 * Plugin Name: Honkai Star Rail EDD Account Form
 * Description: فرم حرفه‌ای ثبت آگهی اکانت Honkai Star Rail و تبدیل داده‌ها به متای محصول Easy Digital Downloads.
 * Version: 1.1.1
 * Author: Honkai Star Rail Dev
 * Text Domain: honkai-star-rail-edd-account-form
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HSR_EDD_FORM_VERSION', '1.1.1' );
define( 'HSR_EDD_FORM_FILE', __FILE__ );
define( 'HSR_EDD_FORM_DIR', plugin_dir_path( __FILE__ ) );
define( 'HSR_EDD_FORM_URL', plugin_dir_url( __FILE__ ) );
define( 'HSR_EDD_CHARACTERS_IMG_SERVER_PATH', '/domains/gamebani.ir/public_html/wp-content/plugins/honkai-star-rail-edd-account-form/assets/img/characters' );
define( 'HSR_EDD_LIGHTCONES_IMG_SERVER_PATH', '/domains/gamebani.ir/public_html/wp-content/plugins/honkai-star-rail-edd-account-form/assets/img/lightcones' );
define( 'HSR_EDD_CHARACTERS_IMG_BASE_URL', trailingslashit( HSR_EDD_FORM_URL . 'assets/img/characters' ) );
define( 'HSR_EDD_LIGHTCONES_IMG_BASE_URL', trailingslashit( HSR_EDD_FORM_URL . 'assets/img/lightcones' ) );
define( 'HSR_EDD_CHARACTERS_IMAGE_EXT', 'png' );
define( 'HSR_EDD_LIGHTCONES_IMAGE_EXT', 'webp' );

require_once HSR_EDD_FORM_DIR . 'includes/class-hsr-edd-account-form-plugin.php';
require_once HSR_EDD_FORM_DIR . 'includes/class-hsr-edd-account-form-admin.php';
require_once HSR_EDD_FORM_DIR . 'includes/class-hsr-edd-account-form-frontend.php';
require_once HSR_EDD_FORM_DIR . 'includes/class-hsr-edd-account-form-product-cards.php';
require_once HSR_EDD_FORM_DIR . 'includes/class-hsr-edd-account-form-single-template.php';
require_once HSR_EDD_FORM_DIR . 'includes/class-hsr-edd-account-form-home-slider.php';
require_once HSR_EDD_FORM_DIR . 'includes/verification-badge.php';
HSR_EDD_Account_Form_Plugin::instance();
