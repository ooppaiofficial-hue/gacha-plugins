document.addEventListener('DOMContentLoaded', function () {
	const gallery = document.querySelector('[data-hsr-gallery]');
	if (!gallery) {
		return;
	}

	const slides = Array.from(gallery.querySelectorAll('[data-gallery-slide]'));
	const thumbs = Array.from(gallery.querySelectorAll('[data-gallery-thumb]'));
	const prevButton = gallery.querySelector('[data-gallery-prev]');
	const nextButton = gallery.querySelector('[data-gallery-next]');
	const lightbox = document.querySelector('[data-hsr-lightbox]');
	const lightboxImage = lightbox ? lightbox.querySelector('[data-lightbox-image]') : null;
	const lightboxClose = lightbox ? lightbox.querySelector('[data-lightbox-close]') : null;
	const lightboxPrev = lightbox ? lightbox.querySelector('[data-lightbox-prev]') : null;
	const lightboxNext = lightbox ? lightbox.querySelector('[data-lightbox-next]') : null;
	let currentIndex = 0;
	let touchStartX = 0;

	function clampIndex(index) {
		if (!slides.length) return 0;
		if (index < 0) return slides.length - 1;
		if (index >= slides.length) return 0;
		return index;
	}

	function updateGallery(index) {
		currentIndex = clampIndex(index);
		slides.forEach((slide, i) => slide.classList.toggle('is-active', i === currentIndex));
		thumbs.forEach((thumb, i) => thumb.classList.toggle('is-active', i === currentIndex));
	}

	function updateLightboxImage() {
		if (!lightboxImage || !slides[currentIndex]) return;
		const image = slides[currentIndex].querySelector('img');
		lightboxImage.src = slides[currentIndex].dataset.full || (image ? image.src : '');
		lightboxImage.alt = image ? image.alt : '';
	}

	function openLightbox(index) {
		if (!lightbox) return;
		updateGallery(index);
		updateLightboxImage();
		lightbox.hidden = false;
		document.body.style.overflow = 'hidden';
	}

	function closeLightbox() {
		if (!lightbox) return;
		lightbox.hidden = true;
		document.body.style.overflow = '';
	}

	slides.forEach((slide, i) => {
		slide.addEventListener('click', () => openLightbox(i));
	});
	thumbs.forEach((thumb, i) => {
		thumb.addEventListener('click', () => updateGallery(i));
	});

	if (prevButton) prevButton.addEventListener('click', () => updateGallery(currentIndex - 1));
	if (nextButton) nextButton.addEventListener('click', () => updateGallery(currentIndex + 1));
	if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
	if (lightboxPrev) {
		lightboxPrev.addEventListener('click', () => {
			updateGallery(currentIndex - 1);
			updateLightboxImage();
		});
	}
	if (lightboxNext) {
		lightboxNext.addEventListener('click', () => {
			updateGallery(currentIndex + 1);
			updateLightboxImage();
		});
	}

	document.addEventListener('keydown', function (event) {
		if (!lightbox || lightbox.hidden) return;
		if (event.key === 'Escape') closeLightbox();
		if (event.key === 'ArrowRight') {
			updateGallery(currentIndex + 1);
			updateLightboxImage();
		}
		if (event.key === 'ArrowLeft') {
			updateGallery(currentIndex - 1);
			updateLightboxImage();
		}
	});

	if (lightbox) {
		lightbox.addEventListener('click', function (event) {
			if (event.target === lightbox) closeLightbox();
		});
	}

	if (lightboxImage) {
		lightboxImage.addEventListener('touchstart', function (event) {
			touchStartX = event.changedTouches[0].clientX;
		}, { passive: true });

		lightboxImage.addEventListener('touchend', function (event) {
			const deltaX = event.changedTouches[0].clientX - touchStartX;
			if (Math.abs(deltaX) < 40) return;
			if (deltaX < 0) updateGallery(currentIndex + 1);
			if (deltaX > 0) updateGallery(currentIndex - 1);
			updateLightboxImage();
		}, { passive: true });
	}

	updateGallery(0);
});
