<?php
/**
 * Single template for Honkai Star Rail Account products.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'hsr_render_meta_value' ) ) {
	/**
	 * @param int    $product_id Product ID.
	 * @param string $meta_key   Meta key.
	 * @return string
	 */
	function hsr_render_meta_value( $product_id, $meta_key ) {
		$value = get_post_meta( $product_id, $meta_key, true );
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		return '' !== $value ? $value : '—';
	}
}

if ( ! function_exists( 'hsr_parse_selected_names' ) ) {
	/**
	 * @param string $raw Raw comma-separated names.
	 * @return array<int, string>
	 */
	function hsr_parse_selected_names( $raw ) {
		if ( ! is_scalar( $raw ) ) {
			return array();
		}

		$parts = array_map( 'trim', explode( ',', (string) $raw ) );
		$parts = array_filter(
			$parts,
			static function ( $item ) {
				return '' !== $item;
			}
		);

		return array_values( array_unique( $parts ) );
	}
}

if ( ! function_exists( 'hsr_build_name_image_map' ) ) {
	/**
	 * @param array<int, array{name:string,file:string}> $items Configured items.
	 * @return array<string, string>
	 */
	function hsr_build_name_image_map( $items, $base_url = '', $expected_extension = '' ) {
		$mapped = array();
		if ( ! is_array( $items ) ) {
			return $mapped;
		}

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['name'] ) || empty( $item['file'] ) ) {
				continue;
			}

			$name = sanitize_text_field( $item['name'] );
			$file = sanitize_file_name( $item['file'] );
			if ( '' === $name || '' === $file ) {
				continue;
			}

			$effective_base_url = '' !== (string) $base_url ? (string) $base_url : HSR_EDD_CHARACTERS_IMG_BASE_URL;
			$normalized_file = $file;
			if ( '' !== (string) $expected_extension ) {
				$normalized_file = pathinfo( $file, PATHINFO_FILENAME ) . '.' . sanitize_key( (string) $expected_extension );
			}
			$mapped[ $name ] = $effective_base_url . ltrim( $normalized_file, '/' );
		}

		return $mapped;
	}
}

if ( ! function_exists( 'hsr_build_seo_titles' ) ) {
	/**
	 * @param string $server Server value.
	 * @param int    $trailblaze_level Trailblaze level.
	 * @return array<string,string>
	 */
	function hsr_build_seo_titles( $server, $trailblaze_level ) {
		$server_label = strtoupper( sanitize_text_field( (string) $server ) );
		$level        = max( 1, absint( $trailblaze_level ) );

		return array(
			'primary' => sprintf( 'honkai: star rail account - %1$s - Lv %2$d', $server_label, $level ),
			'fa'      => sprintf( 'آکانت هونکای استار ریل - %1$s - Lv %2$d', $server_label, $level ),
		);
	}
}

if ( ! function_exists( 'hsr_get_uploaded_gallery_items' ) ) {
	/**
	 * @param int $product_id Product ID.
	 * @return array<int, array{thumb:string,full:string,alt:string}>
	 */
	function hsr_get_uploaded_gallery_items( $product_id ) {
		$raw_ids = get_post_meta( $product_id, HSR_EDD_Account_Form_Frontend::UPLOADED_IMAGE_META_KEY, true );
		if ( ! is_scalar( $raw_ids ) || '' === trim( (string) $raw_ids ) ) {
			return array();
		}

		$ids = array_map( 'absint', array_filter( array_map( 'trim', explode( ',', (string) $raw_ids ) ) ) );
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		if ( empty( $ids ) ) {
			return array();
		}

		$items = array();
		foreach ( $ids as $id ) {
			$full  = wp_get_attachment_image_url( $id, 'large' );
			$thumb = wp_get_attachment_image_url( $id, 'medium' );
			if ( ! $full ) {
				continue;
			}

			$items[] = array(
				'thumb' => $thumb ? $thumb : $full,
				'full'  => $full,
				'alt'   => get_post_meta( $id, '_wp_attachment_image_alt', true ) ? get_post_meta( $id, '_wp_attachment_image_alt', true ) : get_the_title( $product_id ),
			);
		}

		return $items;
	}
}

get_header();

while ( have_posts() ) :
	the_post();

	$product_id = get_the_ID();
	$meta_map   = array(
		'hsr_trailblaze_level'       => 'تربلیز لول',
		'hsr_server'                => 'سرور',
		'hsr_character_event_warp_pity' => 'پیتی وارپ کاراکتر',
		'hsr_light_cone_event_warp_pity'    => 'پیتی وارپ لایت‌کون',
		'hsr_standard_warp_pity'  => 'پیتی وارپ استاندارد',
		'hsr_star_rail_passes'        => 'تعداد پاس مانده',
		'hsr_stellar_jade'               => 'استلار جید',
		'hsr_oneiric_shard'             => 'وانیریک شارد',
		'hsr_special_passes'        => 'تعداد اسپشیال پس',
	);

	$character_names = hsr_parse_selected_names( get_post_meta( $product_id, 'hsr_selected_characters', true ) );
	$weapon_names    = hsr_parse_selected_names( get_post_meta( $product_id, 'hsr_selected_light_cones', true ) );

	$character_image_map = hsr_build_name_image_map( get_option( HSR_EDD_Account_Form_Admin::OPTION_CHARACTER_IMAGES, array() ), HSR_EDD_CHARACTERS_IMG_BASE_URL, HSR_EDD_CHARACTERS_IMAGE_EXT );
	$weapon_image_map    = hsr_build_name_image_map( get_option( HSR_EDD_Account_Form_Admin::OPTION_LIGHT_CONE_IMAGES, array() ), HSR_EDD_LIGHTCONES_IMG_BASE_URL, HSR_EDD_LIGHTCONES_IMAGE_EXT );
	$gallery_items       = hsr_get_uploaded_gallery_items( $product_id );
	$seo_titles          = hsr_build_seo_titles( get_post_meta( $product_id, 'hsr_server', true ), absint( get_post_meta( $product_id, 'hsr_trailblaze_level', true ) ) );
	$buy_keyword_url     = 'https://gamebani.ir/buy-honkai-star-rail-accoant/';
	$sell_keyword_url    = 'https://gamebani.ir/sell-honkai-star-rail-accoant/';
	$seller_user_id      = (int) get_post_field( 'post_author', $product_id );
	$seller_name         = hsr_get_user_display_name( $seller_user_id );
	if ( '' === $seller_name ) {
		$seller_name = esc_html__( 'فروشنده', 'honkai-star-rail-edd-account-form' );
	}
	$seller_avatar       = hsr_get_user_avatar_url( $seller_user_id, 112 );
	$seller_badge        = hsr_get_verified_badge_html( $seller_user_id, array( 'class' => 'hsr-verified-badge-inline' ) );
	$seller_profile_url  = hsr_get_user_public_profile_url( $seller_user_id );
	$can_start_chat     = is_user_logged_in() && $seller_user_id > 0 && get_current_user_id() !== $seller_user_id;
	$single_keywords     = array(
		'خرید آکانت هونکای استار ریل',
		'خرید آکانت honkai: star rail',
		'فروش آکانت هونکای استار ریل',
		'فروش آکانت honkai: star rail',
		'آکانت حرفه ای هونکای استار ریل',
		'آکانت حرفه ای honkai: star rail',
		'قیمت آکانت هونکای استار ریل',
		'قیمت آکانت honkai: star rail',
	);
	?>
	<main id="primary" class="hsr-single-account">
		<?php if ( ! empty( $gallery_items ) ) : ?>
			<section class="hsr-single-account__panel">
				<div class="hsr-gallery" data-hsr-gallery>
					<button type="button" class="hsr-gallery__nav hsr-gallery__nav--prev" data-gallery-prev aria-label="Previous image">‹</button>
					<div class="hsr-gallery__stage" data-gallery-stage>
						<?php foreach ( $gallery_items as $index => $image ) : ?>
							<button type="button" class="hsr-gallery__slide<?php echo 0 === $index ? ' is-active' : ''; ?>" data-gallery-slide data-index="<?php echo esc_attr( $index ); ?>" data-full="<?php echo esc_url( $image['full'] ); ?>" aria-label="Open image">
								<img src="<?php echo esc_url( $image['full'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" loading="lazy" />
							</button>
						<?php endforeach; ?>
					</div>
					<button type="button" class="hsr-gallery__nav hsr-gallery__nav--next" data-gallery-next aria-label="Next image">›</button>
					<div class="hsr-gallery__thumbs">
						<?php foreach ( $gallery_items as $index => $image ) : ?>
							<button type="button" class="hsr-gallery__thumb<?php echo 0 === $index ? ' is-active' : ''; ?>" data-gallery-thumb data-index="<?php echo esc_attr( $index ); ?>" aria-label="Select image">
								<img src="<?php echo esc_url( $image['thumb'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" loading="lazy" />
							</button>
						<?php endforeach; ?>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<section class="hsr-single-account__panel">
			<div class="hsr-single-account__seller-row">
				<?php if ( '' !== $seller_profile_url ) : ?>
					<a class="hsr-single-account__seller-link" href="<?php echo esc_url( $seller_profile_url ); ?>" target="_blank" rel="noopener noreferrer">
				<?php endif; ?>
				<div class="hsr-single-account__seller">
					<?php if ( ! empty( $seller_avatar ) ) : ?>
						<img class="hsr-single-account__seller-avatar" src="<?php echo esc_url( $seller_avatar ); ?>" alt="<?php echo esc_attr( $seller_name ); ?>" loading="lazy" />
					<?php endif; ?>
					<div class="hsr-single-account__seller-meta">
						<span class="hsr-single-account__seller-label"><?php esc_html_e( 'فروشنده', 'honkai-star-rail-edd-account-form' ); ?></span>
						<span class="hsr-single-account__seller-name"><?php echo esc_html( $seller_name ); ?></span>
						<?php if ( ! empty( $seller_badge ) ) : ?>
							<?php echo $seller_badge; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endif; ?>
					</div>
				</div>
				<?php if ( '' !== $seller_profile_url ) : ?>
					</a>
				<?php endif; ?>

				<?php if ( $can_start_chat ) : ?>
					<button type="button" class="scp-chat-launch scp-chat-launch-profile hsr-chat-launch" data-target-user="<?php echo esc_attr( (string) $seller_user_id ); ?>" data-target-name="<?php echo esc_attr( $seller_name ); ?>">💬 <?php esc_html_e( 'چت با فروشنده', 'honkai-star-rail-edd-account-form' ); ?></button>
				<?php endif; ?>
			</div>
		</section>

		<section class="hsr-single-account__panel">
			<h1 class="hsr-single-account__title"><?php echo esc_html( $seo_titles['primary'] ); ?></h1>
			<p class="hsr-single-account__seo-title"><?php echo esc_html( $seo_titles['fa'] ); ?></p>
			<div class="hsr-single-account__overview">
				<div class="hsr-single-account__item">
					<span class="hsr-single-account__label">نام محصول</span>
					<span class="hsr-single-account__value"><?php echo esc_html( $seo_titles['primary'] ); ?></span>
				</div>
				<div class="hsr-single-account__item">
					<span class="hsr-single-account__label">قیمت محصول</span>
					<span class="hsr-single-account__value"><?php echo esc_html( hsr_render_meta_value( $product_id, 'edd_price' ) ); ?></span>
				</div>
				<div class="hsr-single-account__item">
					<span class="hsr-single-account__label">تاریخ ثبت</span>
					<span class="hsr-single-account__value"><?php echo esc_html( get_the_date( 'Y/m/d - H:i', $product_id ) ); ?></span>
				</div>
			</div>
		</section>

		<section class="hsr-single-account__panel">
			<h2>دیتای کامل اکانت</h2>
			<div class="hsr-single-account__grid">
				<?php foreach ( $meta_map as $key => $label ) : ?>
					<div class="hsr-single-account__item">
						<span class="hsr-single-account__label"><?php echo esc_html( $label ); ?></span>
						<span class="hsr-single-account__value"><?php echo esc_html( hsr_render_meta_value( $product_id, $key ) ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="hsr-single-account__panel">
			<h2>کاراکترهای 5 ستاره</h2>
			<div class="hsr-image-grid hsr-image-grid--scrollable">
				<?php if ( empty( $character_names ) ) : ?>
					<p class="hsr-empty">موردی انتخاب نشده است.</p>
				<?php else : ?>
					<?php foreach ( $character_names as $name ) : ?>
						<div class="hsr-card">
							<?php if ( isset( $character_image_map[ $name ] ) ) : ?>
								<img src="<?php echo esc_url( $character_image_map[ $name ] ); ?>" alt="<?php echo esc_attr( $name ); ?>" loading="lazy" />
							<?php endif; ?>
							<span class="hsr-card__name"><?php echo esc_html( $name ); ?></span>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</section>

		<section class="hsr-single-account__panel">
			<h2>لایت‌کون‌های 5 ستاره</h2>
			<div class="hsr-image-grid hsr-image-grid--scrollable">
				<?php if ( empty( $weapon_names ) ) : ?>
					<p class="hsr-empty">موردی انتخاب نشده است.</p>
				<?php else : ?>
					<?php foreach ( $weapon_names as $name ) : ?>
						<div class="hsr-card">
							<?php if ( isset( $weapon_image_map[ $name ] ) ) : ?>
								<img src="<?php echo esc_url( $weapon_image_map[ $name ] ); ?>" alt="<?php echo esc_attr( $name ); ?>" loading="lazy" />
							<?php endif; ?>
							<span class="hsr-card__name"><?php echo esc_html( $name ); ?></span>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</section>

		<section class="hsr-single-account__panel">
			<h2>جزئیات تکمیلی</h2>
			<div class="hsr-single-account__details-stack">
				<div class="hsr-single-account__item">
					<span class="hsr-single-account__label">قیمت</span>
					<span class="hsr-single-account__value"><?php echo esc_html( hsr_render_meta_value( $product_id, 'edd_price' ) ); ?></span>
				</div>
				<div class="hsr-single-account__content-row">
					<div class="hsr-single-account__content">
						<h3>توضیحات</h3>
						<?php echo wp_kses_post( wpautop( get_post_field( 'post_content', $product_id ) ) ); ?>
					</div>
					<div class="hsr-single-account__content">
						<h3>Eidolon کاراکترها</h3>
						<p><?php echo esc_html( hsr_render_meta_value( $product_id, 'hsr_eidolons_summary' ) ); ?></p>
					</div>
				</div>
			</div>
		</section>

		<section class="hsr-single-account__panel">
			<h2>کلمات کلیدی</h2>
			<ul class="hsr-single-account__keywords">
				<?php foreach ( $single_keywords as $keyword ) : ?>
					<?php $keyword_url = false !== mb_strpos( $keyword, 'فروش' ) ? $sell_keyword_url : $buy_keyword_url; ?>
					<li><a href="<?php echo esc_url( $keyword_url ); ?>"><?php echo esc_html( $keyword ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>

		<div class="hsr-lightbox" data-hsr-lightbox hidden>
			<button type="button" class="hsr-lightbox__close" data-lightbox-close aria-label="Close">×</button>
			<img src="" alt="" data-lightbox-image />
		</div>
	</main>
	<?php
endwhile;

get_footer();
